void main() {
  int i = 0;
  while (i < 5) {
    print('Perulangan While: $i');
    i++;
  }
}
