void main() {
  List<String> fruits = ['Apple', 'Banana', 'Cherry'];
  for (var fruit in fruits) {
    print('Perulangan Foreach: $fruit');
  }
}
