void main() {
  int i = 0;
  do {
    print('Perulangan Do/While: $i');
    i++;
  } while (i < 5);
}
