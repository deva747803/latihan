void main() {
  int nilai = 45;

  String hasil = (nilai >= 60) ? "Lulus" : "Tidak Lulus";
  print(hasil);
}
