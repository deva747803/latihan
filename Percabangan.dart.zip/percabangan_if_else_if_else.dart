void main() {
  int nilai = 85;

  if (nilai >= 90) {
    print("Grade A");
  } else if (nilai >= 80) {
    print("Grade B");
  } else if (nilai >= 70) {
    print("Grade C");
  } else {
    print("Grade D");
  }
}
