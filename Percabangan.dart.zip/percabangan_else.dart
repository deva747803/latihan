void main() {
  int nilai = 65;

  if (nilai >= 70) {
    print("Anda Lulus");
  } else {
    print("Anda Tidak Lulus");
  }
}
