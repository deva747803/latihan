void main() {
  int nilai = 75;

  if (nilai >= 70) {
    print("Anda Lulus");
  }
}
