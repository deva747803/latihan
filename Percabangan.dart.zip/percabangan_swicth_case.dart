void main() {
  String hari = "Sabtu";

  switch (hari) {
    case "Senin":
      print("Hari Pertama");
      break;
    case "Selasa":
      print("Hari Kedua");
      break;
    case "Rabu":
      print("Hari Ketiga");
      break;
    case "Kamis":
      print("Hari Keempat");
      break;
    case "Jumat":
      print("Hari Kelima");
      break;
    case "Sabtu":
      print("Hari Keenam");
      break;
    case "Minggu":
      print("Hari Ketujuh");
      break;
    default:
      print("Hari Tidak Dikenal");
  }
}
